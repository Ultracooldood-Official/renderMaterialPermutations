bl_info = {
    "name": "Ultracooldood Material Permutator",
    "author": "Ultracooldood",
    "version": (1, 1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Ultracooldood Tab",
    "description": "Render all permutations of selected materials on chosen objects with adjustable settings.",
    "category": "Ultracooldood",
}

import bpy
import os
import itertools
from bpy.props import StringProperty, IntProperty, EnumProperty

class RENDER_OT_material_permutations(bpy.types.Operator):
    bl_idname = "render.material_permutations"
    bl_label = "Render Material Permutations"
    bl_description = "Render permutations of selected materials on two objects"

    def execute(self, context):
        scene = context.scene
        output_path = scene.ucd_output_path
        material_group_name = scene.ucd_material_group
        obj_inside_name = scene.ucd_object_inside
        obj_outside_name = scene.ucd_object_outside
        samples = scene.ucd_samples
        res_x = scene.ucd_res_x
        res_y = scene.ucd_res_y
        render_engine = scene.ucd_render_engine

        if not os.path.exists(output_path):
            os.makedirs(output_path)
        
        materials = [mat for mat in bpy.data.materials if material_group_name in mat.name]
        print(f"Found {len(materials)} materials in '{material_group_name}'.")

        obj_inside = bpy.data.objects.get(obj_inside_name)
        obj_outside = bpy.data.objects.get(obj_outside_name)

        if not obj_inside or not obj_outside:
            self.report({'ERROR'}, "One or both objects not found.")
            return {'CANCELLED'}

        scene.render.engine = render_engine

        if render_engine == 'CYCLES':
            scene.cycles.samples = samples

        scene.render.resolution_x = res_x
        scene.render.resolution_y = res_y
        scene.render.resolution_percentage = 100

        for i, (mat_inside, mat_outside) in enumerate(itertools.product(materials, repeat=2)):
            obj_inside.active_material = mat_inside
            obj_outside.active_material = mat_outside

            filename = f"{mat_inside.name.replace(material_group_name, '')}_{mat_outside.name.replace(material_group_name, '')}.png"
            filepath = os.path.join(output_path, filename)

            scene.render.filepath = filepath
            bpy.ops.render.render(write_still=True)
            print(f"Rendered {i+1}/{len(materials) ** 2}: {filename}")

        self.report({'INFO'}, "All renders completed!")
        return {'FINISHED'}

class RENDER_PT_material_permutation_panel(bpy.types.Panel):
    bl_label = "Material Permutator"
    bl_idname = "RENDER_PT_material_permutation_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Ultracooldood'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "ucd_output_path")
        layout.prop(scene, "ucd_material_group")
        layout.prop(scene, "ucd_object_inside")
        layout.prop(scene, "ucd_object_outside")
        layout.prop(scene, "ucd_samples")
        layout.prop(scene, "ucd_render_engine")
        layout.prop(scene, "ucd_res_x")
        layout.prop(scene, "ucd_res_y")
        layout.operator("render.material_permutations")

classes = (
    RENDER_OT_material_permutations,
    RENDER_PT_material_permutation_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.ucd_output_path = StringProperty(
        name="Output Path",
        default="",
        subtype='DIR_PATH'
    )
    bpy.types.Scene.ucd_material_group = StringProperty(
        name="Material Group",
        default=""
    )
    bpy.types.Scene.ucd_object_inside = StringProperty(
        name="Object 1",
        default=""
    )
    bpy.types.Scene.ucd_object_outside = StringProperty(
        name="Object 2",
        default=""
    )
    bpy.types.Scene.ucd_samples = IntProperty(
        name="Render Samples",
        default=128,
        min=1,
        max=10000
    )
    bpy.types.Scene.ucd_res_x = IntProperty(
        name="Resolution X",
        default=720,
        min=1
    )
    bpy.types.Scene.ucd_res_y = IntProperty(
        name="Resolution Y",
        default=720,
        min=1
    )
    bpy.types.Scene.ucd_render_engine = EnumProperty(
        name="Render Engine",
        items=[
            ('CYCLES', 'Cycles', ''),
            ('BLENDER_EEVEE', 'Eevee', '')
        ],
        default='CYCLES'
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.ucd_output_path
    del bpy.types.Scene.ucd_material_group
    del bpy.types.Scene.ucd_object_inside
    del bpy.types.Scene.ucd_object_outside
    del bpy.types.Scene.ucd_samples
    del bpy.types.Scene.ucd_res_x
    del bpy.types.Scene.ucd_res_y
    del bpy.types.Scene.ucd_render_engine

if __name__ == "__main__":
    register()
